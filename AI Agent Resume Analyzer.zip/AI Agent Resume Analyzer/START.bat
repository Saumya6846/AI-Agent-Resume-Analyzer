@echo off
title AI Agent Resume Analyzer
cd /d "%~dp0"
echo Installing dependencies (first run only)...
py -m pip install -r requirements.txt -q
echo.
echo Starting AI Agent Resume Analyzer...
echo Open http://localhost:8501 in your browser
echo.
py -m streamlit run app.py
pause
