"""AI Resume Analyzer + Job Matcher — Streamlit app."""



from __future__ import annotations



import io

import os



import streamlit as st

from dotenv import load_dotenv



from analyzer.ai_analyzer import AnalysisResult, analyze_resume

from analyzer.job_matcher import JobMatch, get_filter_options, match_jobs

from analyzer.pdf_report import generate_report_pdf

from analyzer.resume_parser import SUPPORTED_EXTENSIONS, extract_text



load_dotenv()



st.set_page_config(

    page_title="Resume Analyzer + Job Matcher",

    page_icon="📄",

    layout="wide",

    initial_sidebar_state="expanded",

)



CUSTOM_CSS = """

<style>

    .main-header { font-size: 2.2rem; font-weight: 700; margin-bottom: 0.2rem; }

    .sub-header { color: #94A3B8; font-size: 1rem; margin-bottom: 2rem; }

    .score-ring {

        font-size: 3rem; font-weight: 800; text-align: center;

        padding: 1.5rem; border-radius: 1rem;

        background: linear-gradient(135deg, #1E293B 0%, #334155 100%);

        border: 2px solid #475569;

    }

    .job-card {

        background: #1E293B; border: 1px solid #334155; border-radius: 12px;

        padding: 1.2rem; margin-bottom: 1rem;

    }

    .match-badge {

        display: inline-block; padding: 0.25rem 0.75rem; border-radius: 999px;

        font-weight: 600; font-size: 0.85rem;

    }

    .match-high { background: #065F46; color: #6EE7B7; }

    .match-mid { background: #78350F; color: #FCD34D; }

    .match-low { background: #7F1D1D; color: #FCA5A5; }

    .source-linkedin { color: #0A66C2; font-weight: 600; }

    .source-naukri { color: #4A90D9; font-weight: 600; }

    div[data-testid="stSidebar"] { background: #0F172A; }

</style>

"""

st.markdown(CUSTOM_CSS, unsafe_allow_html=True)





def _score_color(score: int) -> str:

    if score >= 75:

        return "#34D399"

    if score >= 50:

        return "#FBBF24"

    return "#F87171"





def _match_class(score: float) -> str:

    if score >= 70:

        return "match-high"

    if score >= 45:

        return "match-mid"

    return "match-low"





def render_analysis(analysis: AnalysisResult) -> None:

    col1, col2 = st.columns([1, 2])

    with col1:

        color = _score_color(analysis.overall_score)

        st.markdown(

            f'<div class="score-ring" style="color:{color}">{analysis.overall_score}<br>'

            f'<span style="font-size:1rem;color:#94A3B8">/ 100</span></div>',

            unsafe_allow_html=True,

        )

        st.caption(f"Powered by: **{analysis.provider}**")



    with col2:

        st.markdown("#### Executive Summary")

        st.write(analysis.summary)

        if analysis.sections_found:

            st.markdown("**Sections detected:** " + " · ".join(f"`{s}`" for s in analysis.sections_found))



    st.divider()



    c1, c2, c3 = st.columns(3)

    with c1:

        st.markdown("#### ✅ Strengths")

        for s in analysis.strengths:

            st.markdown(f"- {s}")

    with c2:

        st.markdown("#### ⚠️ Weaknesses")

        for w in analysis.weaknesses:

            st.markdown(f"- {w}")

    with c3:

        st.markdown("#### 💡 Improvements")

        for i in analysis.improvements:

            st.markdown(f"- {i}")



    if analysis.missing_keywords:

        st.markdown("#### 🔑 Suggested Keywords to Add")

        st.write(" · ".join(f"`{kw}`" for kw in analysis.missing_keywords))





def render_job_card(job: JobMatch) -> None:

    badge = _match_class(job.match_score)

    source_cls = "source-linkedin" if job.source == "LinkedIn" else "source-naukri"

    st.markdown(

        f'<div class="job-card">'

        f'<div style="display:flex;justify-content:space-between;align-items:start">'

        f'<div><h4 style="margin:0">{job.title}</h4>'

        f'<p style="margin:0.25rem 0;color:#94A3B8">{job.company} · {job.location}</p></div>'

        f'<span class="match-badge {badge}">{job.match_score}% match</span></div>'

        f'<p style="margin:0.75rem 0;font-size:0.9rem">{job.description[:200]}...</p>'

        f'<div style="font-size:0.85rem;color:#94A3B8">'

        f'<span class="{source_cls}">{job.source}</span> · {job.type} · {job.experience} · '

        f'{job.salary} · {job.posted}</div></div>',

        unsafe_allow_html=True,

    )

    cols = st.columns(2)

    with cols[0]:

        if job.skill_overlap:

            st.markdown("**Matching skills:** " + ", ".join(f"`{s}`" for s in job.skill_overlap))

    with cols[1]:

        if job.skill_gaps:

            st.markdown("**Skill gaps:** " + ", ".join(f"`{s}`" for s in job.skill_gaps))





def main() -> None:

    st.markdown('<p class="main-header">📄 AI Resume Analyzer + Job Matcher</p>', unsafe_allow_html=True)

    st.markdown(

        '<p class="sub-header">Upload your resume → AI finds weaknesses → Suggests improvements → Matches jobs</p>',

        unsafe_allow_html=True,

    )



    with st.sidebar:

        st.header("⚙️ Settings")

        provider = st.selectbox(

            "AI Provider",

            ["auto", "openai", "ollama", "rule-based"],

            help="Auto picks OpenAI → Ollama → rule-based fallback",

        )

        filters = get_filter_options()

        source_filter = st.selectbox("Job Source", filters["sources"])

        location_filter = st.selectbox("Location", filters["locations"])

        top_n = st.slider("Max job matches", 3, 15, 8)



        st.divider()

        st.markdown("**Supported formats**")

        st.code(", ".join(sorted(SUPPORTED_EXTENSIONS)))



        if not os.getenv("OPENAI_API_KEY"):

            st.info("💡 Add `OPENAI_API_KEY` to `.env` for best results, or run Ollama locally.")



    uploaded = st.file_uploader(

        "Upload your resume",

        type=["pdf", "docx", "txt", "md"],

        help="PDF, Word (.docx), or plain text",

    )



    if not uploaded:

        st.info("👆 Upload a resume to get started.")

        with st.expander("How it works"):

            st.markdown(

                """

                1. **Upload** — PDF, DOCX, or TXT resume

                2. **Analyze** — AI scans for strengths, weaknesses, and ATS issues

                3. **Improve** — Get actionable suggestions to strengthen your resume

                4. **Match** — Find relevant jobs from LinkedIn & Naukri (mock data)

                """

            )

        return



    file_bytes = uploaded.read()

    try:

        resume_text = extract_text(io.BytesIO(file_bytes), uploaded.name)

    except Exception as e:

        st.error(f"Could not parse file: {e}")

        return



    if not resume_text.strip():

        st.warning("No text could be extracted. Try a different file or format.")

        return



    with st.expander("📋 Extracted Resume Text", expanded=False):

        st.text(resume_text[:8000] + ("..." if len(resume_text) > 8000 else ""))



    with st.spinner("Analyzing resume and matching jobs..."):

        analysis = analyze_resume(resume_text, provider=provider)

        jobs = match_jobs(

            resume_text,

            top_n=top_n,

            source_filter=source_filter,

            location_filter=location_filter,

        )



    pdf_bytes = generate_report_pdf(analysis, jobs, resume_filename=uploaded.name)

    st.download_button(

        label="📥 Download PDF Report",

        data=pdf_bytes,

        file_name=f"resume_analysis_{uploaded.name.rsplit('.', 1)[0]}.pdf",

        mime="application/pdf",

        type="primary",

    )



    tab_analysis, tab_jobs = st.tabs(["🔍 Resume Analysis", "💼 Job Matches"])



    with tab_analysis:

        render_analysis(analysis)



    with tab_jobs:

        st.markdown("#### Top Job Matches")

        if not jobs:

            st.warning("No jobs found for the selected filters.")

        else:

            for job in jobs:

                render_job_card(job)

                st.divider()





if __name__ == "__main__":

    main()

