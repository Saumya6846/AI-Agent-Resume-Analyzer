# AI Agent Resume Analyzer

Upload a resume, get AI-powered feedback, and discover matching jobs.

## Quick Start

**Double-click `START.bat`** on your Desktop, or run:

```powershell
cd "$env:USERPROFILE\OneDrive\Desktop\AI Agent Resume Analyzer"
py -m pip install -r requirements.txt
py -m streamlit run app.py
```

Open http://localhost:8501

## Features

- Resume upload (PDF, DOCX, TXT)
- AI analysis — strengths, weaknesses, improvements, ATS score
- Job matching — LinkedIn & Naukri mock listings
- PDF report download

## Optional: Better AI

Copy `.env.example` to `.env` and add your OpenAI API key, or run Ollama locally.
