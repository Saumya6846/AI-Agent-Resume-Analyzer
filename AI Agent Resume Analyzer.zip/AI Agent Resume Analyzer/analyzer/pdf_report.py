"""Generate a downloadable PDF analysis report."""



from __future__ import annotations



from datetime import datetime

from io import BytesIO



from reportlab.lib import colors

from reportlab.lib.enums import TA_CENTER

from reportlab.lib.pagesizes import A4

from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet

from reportlab.lib.units import inch

from reportlab.platypus import (

    HRFlowable,

    PageBreak,

    Paragraph,

    SimpleDocTemplate,

    Spacer,

    Table,

    TableStyle,

)



from analyzer.ai_analyzer import AnalysisResult

from analyzer.job_matcher import JobMatch





def generate_report_pdf(

    analysis: AnalysisResult,

    jobs: list[JobMatch],

    resume_filename: str = "resume",

) -> bytes:

    """Build a PDF report and return raw bytes."""

    buffer = BytesIO()

    doc = SimpleDocTemplate(

        buffer,

        pagesize=A4,

        rightMargin=0.75 * inch,

        leftMargin=0.75 * inch,

        topMargin=0.75 * inch,

        bottomMargin=0.75 * inch,

    )



    styles = getSampleStyleSheet()

    title_style = ParagraphStyle(

        "ReportTitle",

        parent=styles["Title"],

        fontSize=22,

        textColor=colors.HexColor("#1E293B"),

        spaceAfter=6,

    )

    subtitle_style = ParagraphStyle(

        "ReportSubtitle",

        parent=styles["Normal"],

        fontSize=10,

        textColor=colors.HexColor("#64748B"),

        spaceAfter=20,

    )

    heading_style = ParagraphStyle(

        "SectionHeading",

        parent=styles["Heading2"],

        fontSize=14,

        textColor=colors.HexColor("#6366F1"),

        spaceBefore=16,

        spaceAfter=8,

    )

    body_style = ParagraphStyle(

        "Body",

        parent=styles["Normal"],

        fontSize=10,

        leading=14,

        textColor=colors.HexColor("#334155"),

    )

    bullet_style = ParagraphStyle(

        "Bullet",

        parent=body_style,

        leftIndent=14,

        bulletIndent=0,

        spaceBefore=3,

    )



    story: list = []



    story.append(Paragraph("Resume Analysis Report", title_style))

    story.append(

        Paragraph(

            f"File: {_escape(resume_filename)} &nbsp;|&nbsp; "

            f"Generated: {datetime.now().strftime('%B %d, %Y at %H:%M')} &nbsp;|&nbsp; "

            f"AI Provider: {_escape(analysis.provider)}",

            subtitle_style,

        )

    )

    story.append(HRFlowable(width="100%", thickness=2, color=colors.HexColor("#6366F1")))

    story.append(Spacer(1, 16))



    score_color = _score_hex(analysis.overall_score)

    score_data = [

        [

            Paragraph(

                f'<font size="28" color="{score_color}"><b>{analysis.overall_score}</b></font>'

                f'<font size="12" color="#64748B"> / 100</font>',

                ParagraphStyle("Score", alignment=TA_CENTER),

            )

        ],

        [Paragraph("Overall Resume Score", ParagraphStyle("ScoreLabel", alignment=TA_CENTER, fontSize=11))],

    ]

    score_table = Table(score_data, colWidths=[3 * inch])

    score_table.setStyle(

        TableStyle(

            [

                ("BACKGROUND", (0, 0), (-1, -1), colors.HexColor("#F1F5F9")),

                ("BOX", (0, 0), (-1, -1), 1, colors.HexColor("#CBD5E1")),

                ("ALIGN", (0, 0), (-1, -1), "CENTER"),

                ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),

                ("TOPPADDING", (0, 0), (-1, 0), 16),

                ("BOTTOMPADDING", (0, 1), (-1, 1), 12),

            ]

        )

    )

    story.append(score_table)

    story.append(Spacer(1, 20))



    story.append(Paragraph("Executive Summary", heading_style))

    story.append(Paragraph(_escape(analysis.summary), body_style))



    if analysis.sections_found:

        story.append(Spacer(1, 8))

        sections_text = ", ".join(analysis.sections_found)

        story.append(

            Paragraph(f"<b>Sections detected:</b> {_escape(sections_text)}", body_style)

        )



    story.append(Paragraph("Strengths", heading_style))

    story.extend(_bullet_list(analysis.strengths, bullet_style))



    story.append(Paragraph("Weaknesses", heading_style))

    story.extend(_bullet_list(analysis.weaknesses, bullet_style))



    story.append(Paragraph("Recommended Improvements", heading_style))

    story.extend(_bullet_list(analysis.improvements, bullet_style))



    if analysis.missing_keywords:

        story.append(Paragraph("Suggested Keywords to Add", heading_style))

        kw_text = ", ".join(analysis.missing_keywords)

        story.append(Paragraph(_escape(kw_text), body_style))



    if jobs:

        story.append(PageBreak())

        story.append(Paragraph("Top Job Matches", title_style))

        story.append(

            Paragraph(

                f"{len(jobs)} jobs ranked by skill overlap and relevance",

                subtitle_style,

            )

        )

        story.append(HRFlowable(width="100%", thickness=1, color=colors.HexColor("#CBD5E1")))

        story.append(Spacer(1, 12))



        for i, job in enumerate(jobs, 1):

            story.append(

                Paragraph(

                    f"{i}. {_escape(job.title)} — {_escape(job.company)}",

                    ParagraphStyle(

                        "JobTitle",

                        parent=styles["Heading3"],

                        fontSize=12,

                        textColor=colors.HexColor("#1E293B"),

                        spaceBefore=10,

                        spaceAfter=4,

                    ),

                )

            )

            meta = (

                f"{job.location} | {job.source} | {job.type} | "

                f"{job.experience} | {job.salary} | Match: {job.match_score}%"

            )

            story.append(Paragraph(_escape(meta), body_style))

            story.append(Paragraph(_escape(job.description[:300] + "..."), body_style))



            if job.skill_overlap:

                story.append(

                    Paragraph(

                        f"<b>Matching skills:</b> {_escape(', '.join(job.skill_overlap))}",

                        body_style,

                    )

                )

            if job.skill_gaps:

                story.append(

                    Paragraph(

                        f"<b>Skill gaps:</b> {_escape(', '.join(job.skill_gaps))}",

                        body_style,

                    )

                )

            story.append(Spacer(1, 6))



    doc.build(story)

    return buffer.getvalue()





def _bullet_list(items: list[str], style: ParagraphStyle) -> list:

    if not items:

        return [Paragraph("None identified.", style)]

    return [Paragraph(f"• {_escape(item)}", style) for item in items]





def _escape(text: str) -> str:

    return (

        text.replace("&", "&amp;")

        .replace("<", "&lt;")

        .replace(">", "&gt;")

        .replace('"', "&quot;")

    )





def _score_hex(score: int) -> str:

    if score >= 75:

        return "#059669"

    if score >= 50:

        return "#D97706"

    return "#DC2626"

