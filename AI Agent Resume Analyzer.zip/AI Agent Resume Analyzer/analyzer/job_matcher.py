"""Match resume text against job listings using TF-IDF and skill overlap."""



from __future__ import annotations



import json

from dataclasses import dataclass

from pathlib import Path



from sklearn.feature_extraction.text import TfidfVectorizer

from sklearn.metrics.pairwise import cosine_similarity



DATA_PATH = Path(__file__).resolve().parent.parent / "data" / "mock_jobs.json"





@dataclass

class JobMatch:

    id: str

    title: str

    company: str

    location: str

    source: str

    type: str

    experience: str

    salary: str

    posted: str

    skills: list[str]

    description: str

    match_score: float

    skill_overlap: list[str]

    skill_gaps: list[str]





def load_jobs(source_filter: str | None = None) -> list[dict]:

    with open(DATA_PATH, encoding="utf-8") as f:

        jobs = json.load(f)

    if source_filter and source_filter != "All":

        jobs = [j for j in jobs if j["source"] == source_filter]

    return jobs





def match_jobs(

    resume_text: str,

    top_n: int = 8,

    source_filter: str | None = None,

    location_filter: str | None = None,

) -> list[JobMatch]:

    jobs = load_jobs(source_filter)



    if location_filter and location_filter != "All":

        loc = location_filter.lower()

        jobs = [j for j in jobs if loc in j["location"].lower()]



    if not jobs:

        return []



    resume_lower = resume_text.lower()

    resume_skills = _extract_skills_from_text(resume_lower)



    job_docs = []

    for job in jobs:

        doc = " ".join(

            [

                job["title"],

                job["company"],

                job["description"],

                " ".join(job["skills"]),

                job["location"],

            ]

        )

        job_docs.append(doc)



    vectorizer = TfidfVectorizer(stop_words="english", ngram_range=(1, 2), max_features=5000)

    matrix = vectorizer.fit_transform([resume_text] + job_docs)

    similarities = cosine_similarity(matrix[0:1], matrix[1:]).flatten()



    results: list[JobMatch] = []

    for idx, job in enumerate(jobs):

        overlap = [s for s in job["skills"] if s.lower() in resume_skills or s.lower() in resume_lower]

        gaps = [s for s in job["skills"] if s.lower() not in resume_lower]



        skill_ratio = len(overlap) / max(len(job["skills"]), 1)

        combined = 0.6 * float(similarities[idx]) + 0.4 * skill_ratio

        score = round(combined * 100, 1)



        results.append(

            JobMatch(

                id=job["id"],

                title=job["title"],

                company=job["company"],

                location=job["location"],

                source=job["source"],

                type=job["type"],

                experience=job["experience"],

                salary=job["salary"],

                posted=job["posted"],

                skills=job["skills"],

                description=job["description"],

                match_score=score,

                skill_overlap=overlap,

                skill_gaps=gaps[:5],

            )

        )



    results.sort(key=lambda m: m.match_score, reverse=True)

    return results[:top_n]





def _extract_skills_from_text(text: str) -> set[str]:

    known = {

        "python", "java", "javascript", "typescript", "react", "node.js", "nodejs",

        "sql", "postgresql", "mysql", "mongodb", "redis", "aws", "azure", "gcp",

        "docker", "kubernetes", "terraform", "jenkins", "git", "ci/cd", "agile",

        "scrum", "machine learning", "deep learning", "tensorflow", "pytorch",

        "django", "fastapi", "spring boot", "kotlin", "android", "figma",

        "selenium", "rest api", "graphql", "microservices", "kafka", "linux",

        "solidity", "blockchain", "excel", "power bi", "go", "rust", "html", "css",

    }

    return {skill for skill in known if skill in text}





def get_filter_options() -> dict[str, list[str]]:

    jobs = load_jobs()

    sources = sorted({j["source"] for j in jobs})

    locations = sorted({j["location"].split(",")[0].strip() for j in jobs})

    return {"sources": ["All"] + sources, "locations": ["All"] + locations}

