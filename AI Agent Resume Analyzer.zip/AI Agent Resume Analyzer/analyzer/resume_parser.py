"""Extract plain text from resume files (PDF, DOCX, TXT)."""



from __future__ import annotations



import io

from typing import BinaryIO





SUPPORTED_EXTENSIONS = {".pdf", ".docx", ".txt", ".md"}





def extract_text(file: BinaryIO, filename: str) -> str:

    """Parse resume bytes into plain text based on file extension."""

    name = filename.lower()

    if name.endswith(".pdf"):

        return _from_pdf(file)

    if name.endswith(".docx"):

        return _from_docx(file)

    if name.endswith((".txt", ".md")):

        return file.read().decode("utf-8", errors="replace").strip()

    raise ValueError(

        f"Unsupported file type. Supported: {', '.join(sorted(SUPPORTED_EXTENSIONS))}"

    )





def _from_pdf(file: BinaryIO) -> str:

    from pypdf import PdfReader



    reader = PdfReader(file)

    parts: list[str] = []

    for page in reader.pages:

        text = page.extract_text()

        if text:

            parts.append(text)

    return "\n".join(parts).strip()





def _from_docx(file: BinaryIO) -> str:

    from docx import Document



    doc = Document(io.BytesIO(file.read()))

    parts = [p.text.strip() for p in doc.paragraphs if p.text.strip()]

    return "\n".join(parts).strip()

