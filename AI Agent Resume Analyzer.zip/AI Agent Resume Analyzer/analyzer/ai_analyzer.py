"""AI-powered resume analysis: weaknesses, improvements, and scoring."""



from __future__ import annotations



import json

import os

import re

from dataclasses import dataclass, field

from typing import Any



import httpx





@dataclass

class AnalysisResult:

    overall_score: int

    summary: str

    strengths: list[str]

    weaknesses: list[str]

    improvements: list[str]

    missing_keywords: list[str] = field(default_factory=list)

    sections_found: list[str] = field(default_factory=list)

    provider: str = "rule-based"





ANALYSIS_PROMPT = """You are an expert career coach and ATS (Applicant Tracking System) specialist.



Analyze the following resume and respond with ONLY valid JSON (no markdown, no code fences):



{

  "overall_score": <integer 0-100>,

  "summary": "<2-3 sentence executive summary>",

  "strengths": ["<strength 1>", "<strength 2>", ...],

  "weaknesses": ["<weakness 1>", "<weakness 2>", ...],

  "improvements": ["<actionable improvement 1>", "<actionable improvement 2>", ...],

  "missing_keywords": ["<keyword missing but valuable>", ...],

  "sections_found": ["<section name>", ...]

}



Be specific, constructive, and actionable. Focus on ATS compatibility, clarity, quantified achievements, and industry relevance.



RESUME:

---

{resume_text}

---

"""





def analyze_resume(resume_text: str, provider: str = "auto") -> AnalysisResult:

    """Run AI analysis with OpenAI, Ollama, or rule-based fallback."""

    if not resume_text.strip():

        raise ValueError("Resume text is empty. Upload a readable file.")



    if provider == "auto":

        if os.getenv("OPENAI_API_KEY"):

            provider = "openai"

        elif _ollama_available():

            provider = "ollama"

        else:

            provider = "rule-based"



    if provider == "openai":

        try:

            return _analyze_openai(resume_text)

        except Exception:

            pass

    if provider == "ollama":

        try:

            return _analyze_ollama(resume_text)

        except Exception:

            pass



    return _analyze_rule_based(resume_text)





def _ollama_available() -> bool:

    base = os.getenv("OLLAMA_BASE_URL", "http://localhost:11434")

    try:

        r = httpx.get(f"{base}/api/tags", timeout=2.0)

        return r.status_code == 200

    except Exception:

        return False





def _analyze_openai(resume_text: str) -> AnalysisResult:

    from openai import OpenAI



    client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

    model = os.getenv("OPENAI_MODEL", "gpt-4o-mini")

    prompt = ANALYSIS_PROMPT.format(resume_text=resume_text[:12000])



    response = client.chat.completions.create(

        model=model,

        messages=[{"role": "user", "content": prompt}],

        temperature=0.3,

        response_format={"type": "json_object"},

    )

    raw = response.choices[0].message.content or "{}"

    data = json.loads(raw)

    return _to_result(data, provider="openai")





def _analyze_ollama(resume_text: str) -> AnalysisResult:

    base = os.getenv("OLLAMA_BASE_URL", "http://localhost:11434")

    model = os.getenv("OLLAMA_MODEL", "llama3.2")

    prompt = ANALYSIS_PROMPT.format(resume_text=resume_text[:12000])



    r = httpx.post(

        f"{base}/api/chat",

        json={

            "model": model,

            "messages": [{"role": "user", "content": prompt}],

            "stream": False,

            "format": "json",

        },

        timeout=120.0,

    )

    r.raise_for_status()

    raw = r.json()["message"]["content"]

    data = json.loads(raw)

    return _to_result(data, provider="ollama")





def _to_result(data: dict[str, Any], provider: str) -> AnalysisResult:

    return AnalysisResult(

        overall_score=int(data.get("overall_score", 50)),

        summary=str(data.get("summary", "")),

        strengths=list(data.get("strengths", [])),

        weaknesses=list(data.get("weaknesses", [])),

        improvements=list(data.get("improvements", [])),

        missing_keywords=list(data.get("missing_keywords", [])),

        sections_found=list(data.get("sections_found", [])),

        provider=provider,

    )





def _analyze_rule_based(resume_text: str) -> AnalysisResult:

    """Heuristic analysis when no LLM is available."""

    text = resume_text.lower()



    sections = []

    section_keywords = {

        "Contact": ["email", "phone", "linkedin", "@"],

        "Summary": ["summary", "objective", "profile", "about me"],

        "Experience": ["experience", "employment", "work history"],

        "Education": ["education", "degree", "university", "bachelor", "master"],

        "Skills": ["skills", "technologies", "technical skills"],

        "Projects": ["projects", "portfolio"],

        "Certifications": ["certification", "certified"],

    }

    for name, kws in section_keywords.items():

        if any(kw in text for kw in kws):

            sections.append(name)



    strengths: list[str] = []

    weaknesses: list[str] = []

    improvements: list[str] = []



    word_count = len(resume_text.split())

    if word_count >= 300:

        strengths.append("Resume has sufficient detail and length.")

    else:

        weaknesses.append("Resume is too short — aim for 300–600 words.")

        improvements.append("Expand bullet points with context, tools used, and outcomes.")



    if re.search(r"\d+%|\$\d+|\d+\s*(users|clients|projects|team)", text):

        strengths.append("Includes quantified achievements (numbers/metrics).")

    else:

        weaknesses.append("Lacks quantified achievements.")

        improvements.append(

            'Add metrics: "Increased sales by 25%", "Managed team of 8", "Reduced latency by 40%".'

        )



    if "@" in text and re.search(r"\b\d{3}[-.\s]?\d{3}[-.\s]?\d{4}\b", resume_text):

        strengths.append("Contact information appears present.")

    else:

        weaknesses.append("Missing or incomplete contact details.")

        improvements.append("Add email, phone, LinkedIn URL, and city/location.")



    skill_hits = sum(

        1

        for s in [

            "python", "java", "javascript", "react", "sql", "aws", "docker",

            "kubernetes", "machine learning", "data analysis",

        ]

        if s in text

    )

    if skill_hits >= 3:

        strengths.append(f"Lists relevant technical skills ({skill_hits}+ detected).")

    else:

        weaknesses.append("Skills section could be stronger or more specific.")

        improvements.append("Add a dedicated Skills section with tools, frameworks, and proficiency levels.")



    if len(sections) >= 4:

        strengths.append(f"Covers key resume sections: {', '.join(sections)}.")

    else:

        weaknesses.append(f"Missing standard sections (found: {', '.join(sections) or 'none'}).")

        improvements.append("Include: Summary, Experience, Education, Skills, and Projects if applicable.")



    action_verbs = ["led", "built", "developed", "designed", "implemented", "managed", "created"]

    verb_count = sum(1 for v in action_verbs if v in text)

    if verb_count >= 3:

        strengths.append("Uses strong action verbs in descriptions.")

    else:

        improvements.append('Start bullet points with action verbs: Led, Built, Designed, Implemented.')



    score = 45

    score += min(20, len(sections) * 4)

    score += min(15, skill_hits * 3)

    score += 10 if word_count >= 300 else 0

    score += 10 if verb_count >= 3 else 0

    score += 10 if re.search(r"\d+%", text) else 0

    score = min(85, score)



    return AnalysisResult(

        overall_score=score,

        summary=(

            f"Rule-based scan of a {word_count}-word resume covering {len(sections)} sections. "

            "Connect OpenAI or Ollama for deeper AI-powered feedback."

        ),

        strengths=strengths or ["Resume uploaded successfully."],

        weaknesses=weaknesses or ["Enable AI for detailed weakness analysis."],

        improvements=improvements,

        missing_keywords=_suggest_keywords(text),

        sections_found=sections,

        provider="rule-based",

    )





def _suggest_keywords(text: str) -> list[str]:

    common = [

        "agile", "scrum", "ci/cd", "git", "rest api", "cloud",

        "leadership", "communication", "problem solving", "data-driven",

    ]

    return [kw.title() for kw in common if kw not in text][:5]

